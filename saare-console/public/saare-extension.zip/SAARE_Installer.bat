﻿@echo off
title S.A.A.R.E. L7 Compliance Gateway - 1-Click Launcher
set TARGET_DIR=%LOCALAPPDATA%\SAARE\extension
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
xcopy /Y /E /I "saare-files\*" "%TARGET_DIR%\" >nul

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --load-extension="%TARGET_DIR%" "https://chatgpt.com"
    exit
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --load-extension="%TARGET_DIR%" "https://chatgpt.com"
    exit
)
start chrome.exe --load-extension="%TARGET_DIR%" "https://chatgpt.com"
exit
