﻿@echo off
:: Comprobar si se ejecuta con permisos de administrador
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Solicitando permisos administrativos...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

title S.A.A.R.E. Runtime - Instalador Corporativo Desatendido L7
echo ============================================================
echo   S.A.A.R.E. L7 Gateway - Despliegue Silencioso Enterprise
echo ============================================================
echo.

set TARGET_DIR=%PROGRAMFILES%\SAARE\extension
echo [1/3] Creando directorio en: %TARGET_DIR%
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo [2/3] Copiando archivos de proteccion perimetral...
xcopy /Y /E /I "saare-files\*" "%TARGET_DIR%\" >nul

echo [3/3] Registrando directivas en Windows (Chrome & MS Edge)...
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "DeveloperToolsAvailability" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DeveloperToolsAvailability" /t REG_DWORD /d 1 /f >nul 2>&1

echo.
echo ============================================================
echo   DESPLIEGUE SILENCIOSO COMPLETADO CON EXITO
echo ============================================================
timeout /t 3 >nul
exit
