/* S.A.A.R.E. L7 RAM Network Interceptor & Sanitizer v8.7.0 */
(function() {
  const DLP = {
    dni: /(?:^|\D)(\d{7,9}[-\s]?[A-Za-z]|[XYZ]\d{7}[-\s]?[A-Za-z])(?!\w)/gi,
    iban: /ES\d{2}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{2}[\s-]?\d{10}|ES\d{18,22}/gi,
    card: /(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})/gi
  };

  function computeL7Seal(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return `L7-SEAL:${Math.abs(hash).toString(16).toUpperCase().padStart(8, "0")}`;
  }

  function showSaareBanner(check, onSanitizeAndContinue, onBlock) {
    try {
      let existing = document.getElementById('saare-violation-banner');
      if (existing) existing.remove();

      const banner = document.createElement('div');
      banner.id = 'saare-violation-banner';
      banner.style.cssText = `
        position: fixed; top: 20px; right: 20px; z-index: 999999; width: 410px;
        background: #0b0f19; border: 2px solid #ef4444; border-radius: 10px; padding: 16px;
        color: #f8fafc; font-family: system-ui, -apple-system, sans-serif;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.8), 0 0 15px rgba(239, 68, 68, 0.4);
      `;

      banner.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; border-bottom: 1px solid #1e293b; padding-bottom: 8px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 18px;">🛡️</span>
            <span style="font-weight: 900; font-size: 11.5px; color: #ef4444; letter-spacing: 0.5px;">S.A.A.R.E. SENSOR L7 · BLOQUEO EX-ANTE</span>
          </div>
          <button id="saare-close-banner" style="background: none; border: none; color: #94a3b8; cursor: pointer; font-size: 16px; font-weight: bold;">✕</button>
        </div>
        <div style="font-size: 11px; color: #94a3b8; margin-bottom: 4px;">NORMATIVA: <strong style="color: #38bdf8;">${check.norma}</strong></div>
        <div style="font-size: 11px; color: #94a3b8; margin-bottom: 6px;">DICTAMEN: <strong style="color: #ef4444;">${check.verdict} (${check.category})</strong></div>
        <div style="background: #020617; border: 1px solid #1e293b; border-radius: 6px; padding: 8px; font-family: monospace; font-size: 11px; color: #34d399; margin-bottom: 10px; word-break: break-all; max-height: 90px; overflow-y: auto;">
          ${check.cleanPrompt}
        </div>
        <div style="display: flex; gap: 8px; margin-bottom: 10px;">
          <button id="saare-btn-sanitize" style="flex: 1; background: #059669; color: #fff; border: none; border-radius: 6px; padding: 8px; font-size: 11px; font-weight: bold; cursor: pointer;">✨ Sanitizar y Continuar</button>
          <button id="saare-btn-block" style="background: #334155; color: #f8fafc; border: none; border-radius: 6px; padding: 8px; font-size: 11px; font-weight: bold; cursor: pointer;">Bloquear</button>
        </div>
      `;

      document.body.appendChild(banner);

      const closeAction = () => { banner.remove(); if (onBlock) onBlock(); };
      const sanitizeAction = () => { banner.remove(); if (onSanitizeAndContinue) onSanitizeAndContinue(); };

      document.getElementById('saare-close-banner').onclick = closeAction;
      document.getElementById('saare-btn-block').onclick = closeAction;
      document.getElementById('saare-btn-sanitize').onclick = sanitizeAction;

    } catch (e) {
      if (onBlock) onBlock();
    }
  }

  function isIgnoredRequest(url, bodyStr) {
    if (url) {
      const u = String(url).toLowerCase();
      if (u.includes("/log?") || u.includes("google-analytics") || u.includes("gen_204") || u.includes("favicon") || u.includes("telemetry") || u.includes("page_locale")) {
        return true;
      }
    }
    if (!bodyStr || bodyStr.length < 3) return true;
    return false;
  }

  function parseBody(body) {
    if (!body) return "";
    if (typeof body === "string") return body;
    try { return JSON.stringify(body); } catch { return String(body); }
  }

  function extractCleanPrompt(rawText) {
    if (!rawText) return "";
    
    if (rawText.includes("f.req")) {
      try {
        const params = new URLSearchParams(rawText);
        const fReqValue = params.get("f.req");
        if (fReqValue) {
          const outer = JSON.parse(fReqValue);
          if (Array.isArray(outer) && outer.length >= 2 && typeof outer[1] === "string") {
            const inner = JSON.parse(outer[1]);
            if (Array.isArray(inner) && inner[0] && inner[0][0]) {
              return String(inner[0][0]).trim();
            }
          }
        }
      } catch {}
    }

    try {
      const json = JSON.parse(rawText);
      if (json.messages && Array.isArray(json.messages)) {
        const lastMsg = json.messages[json.messages.length - 1];
        if (lastMsg && lastMsg.content) return typeof lastMsg.content === 'string' ? lastMsg.content : JSON.stringify(lastMsg.content);
      }
      if (json.prompt) return json.prompt;
      if (json.input) return json.input;
    } catch {}

    return decodeURIComponent(rawText.replace(/\+/g, " "));
  }

  function sanitizeText(text) {
    if (!text) return "";
    return text
      .replace(DLP.dni, (m, dni) => m.replace(dni, `[DNI_REDACTED_***${dni.slice(-4)}]`))
      .replace(DLP.iban, (m) => `[IBAN_REDACTED_***${m.slice(-4)}]`)
      .replace(DLP.card, (m) => `[CARD_REDACTED_***${m.slice(-4)}]`);
  }

  function evaluatePayload(rawBody, url) {
    const str = parseBody(rawBody);
    if (isIgnoredRequest(url, str)) return null;

    const cleanPrompt = extractCleanPrompt(str) || str;
    if (!cleanPrompt || cleanPrompt.length < 2) return null;

    DLP.dni.lastIndex = 0;
    DLP.iban.lastIndex = 0;
    DLP.card.lastIndex = 0;

    const isDni = DLP.dni.test(cleanPrompt);
    const isIban = DLP.iban.test(cleanPrompt.replace(/[\s-]/g, ""));
    const isCard = DLP.card.test(cleanPrompt.replace(/[\s-]+/g, ""));

    if (isDni || isIban || isCard) {
      let category = "PII_DNI";
      let norma = "España - LOPDGDD & AEPD";
      if (isIban) { category = "DATOS_BANCARIOS"; norma = "RGPD Art. 5, 32 / LOPDGDD"; }
      else if (isCard) { category = "TARJETA_CREDITO"; norma = "PCI-DSS / RGPD"; }

      return {
        verdict: "RECHAZADO", decision: "DENY", category, norma,
        reason: "Detección de datos regulados en RAM L7",
        rawPrompt: cleanPrompt,
        cleanPrompt: sanitizeText(cleanPrompt),
        cryptoSeal: computeL7Seal(cleanPrompt),
        shouldBlock: true
      };
    } else {
      return {
        verdict: "PERMITIDO", decision: "ALLOW", category: "AUDITORIA_CONFORME",
        norma: "EU AI Act - Tráfico Conforme", reason: "Prompt verificado sin PII en RAM",
        rawPrompt: cleanPrompt, cleanPrompt: cleanPrompt,
        cryptoSeal: computeL7Seal(cleanPrompt), shouldBlock: false
      };
    }
  }

  const rawFetch = window.fetch;
  window.fetch = async function(resource, config) {
    const url = typeof resource === "string" ? resource : (resource?.url || "");

    if (config && config.body) {
      const check = evaluatePayload(config.body, url);
      if (check) {
        window.postMessage({ type: "SAARE_EVENT", data: check }, "*");

        if (check.shouldBlock) {
          return new Promise((resolve) => {
            showSaareBanner(
              check,
              () => {
                try {
                  if (typeof config.body === "string") {
                    config.body = config.body.replace(check.rawPrompt, check.cleanPrompt);
                  }
                } catch (e) {
                  console.error("[S.A.A.R.E.] Error en reemplazo:", e);
                }
                resolve(rawFetch.apply(this, [resource, config]));
              },
              () => {
                resolve(new Response(JSON.stringify({
                  error: "SAARE_GRC_BLOCK",
                  message: "Transmisión abortada ex-ante por normativa LOPDGDD / EU AI Act."
                }), {
                  status: 403,
                  statusText: "Forbidden by SAARE Guardrail",
                  headers: { "Content-Type": "application/json" }
                }));
              }
            );
          });
        }
      }
    }
    return rawFetch.apply(this, arguments);
  };
})();