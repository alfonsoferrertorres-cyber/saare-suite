SAARE Enterprise SDK Package v4.2
