// S.A.A.R.E. Content Script — Interceptor Universal de Interfaces Web de IA en RAM (SGP 1.0)

(function () {
  console.log("[S.A.A.R.E. L7 Proxy] Agente de Inspección Activo.");

  // Interceptar pulsación de teclas (Enter sin Shift) en las cajas de texto de chatbots
  document.addEventListener("keydown", async (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      const inputEl = event.target;
      if (isAiInputField(inputEl)) {
        const rawPrompt = getInputValue(inputEl);
        if (!rawPrompt || !rawPrompt.trim()) return;

        // Detener temporalmente el envío del evento original
        event.preventDefault();
        event.stopPropagation();

        console.log("[S.A.A.R.E. L7] Interceptando Prompt Ex-Ante...");

        try {
          const response = await chrome.runtime.sendMessage({
            action: "INSPECT_PROMPT_EX_ANTE",
            payload: rawPrompt
          });

          if (response && response.success && response.verdict) {
            const verdictData = response.verdict;

            // Bloqueo explícito Ex-Ante (DENY / RECHAZADO)
            if (verdictData.decision === "DENY" || verdictData.verdict === "RECHAZADO") {
              alert(`[S.A.A.R.E. SECURITY BLOCK]\nAcceso Bloqueado por Política Ex-Ante.\n\nEvidencia: ${verdictData.evidence_id || 'N/A'}\nHash MS3V: ${verdictData.enforcement?.ms3vIntegrityHash || 'N/A'}`);
              return;
            }

            // Sustitución por sanitización DLP/PII en RAM únicamente si fue modificada
            const sanitizedPrompt = verdictData.sanitizedPrompt || verdictData.enforcement?.sanitizedPrompt;
            if (sanitizedPrompt && sanitizedPrompt !== rawPrompt) {
              setInputValue(inputEl, sanitizedPrompt);
            }

            // Re-disparar el envío original en el chatbot
            dispatchOriginalSubmit(inputEl);
          } else {
            console.warn("[S.A.A.R.E.] Fallo en inspección, aplicando política de contingencia (Pass-through).");
            dispatchOriginalSubmit(inputEl);
          }
        } catch (err) {
          console.error("[S.A.A.R.E. Proxy Error]:", err);
          dispatchOriginalSubmit(inputEl);
        }
      }
    }
  }, true);

  function isAiInputField(el) {
    if (!el) return false;
    const tag = el.tagName.toLowerCase();
    return tag === "textarea" || el.isContentEditable || el.getAttribute("role") === "textbox";
  }

  function getInputValue(el) {
    if (el.tagName.toLowerCase() === "textarea" || el.tagName.toLowerCase() === "input") {
      return el.value;
    }
    return el.innerText || el.textContent || "";
  }

  function setInputValue(el, text) {
    if (el.tagName.toLowerCase() === "textarea" || el.tagName.toLowerCase() === "input") {
      el.value = text;
    } else if (el.isContentEditable) {
      el.innerText = text;
    }
    // Disparar eventos reactivos para React/Angular/Vue
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function dispatchOriginalSubmit(el) {
    // 1. Intentar enviar mediante el formulario si existe
    const form = el.closest("form");
    if (form && typeof form.requestSubmit === "function") {
      try {
        form.requestSubmit();
        return;
      } catch (e) {
        console.warn("[S.A.A.R.E.] Buscando botón de envío por fallback...");
      }
    }

    // 2. Fallback de envío para chatbots en SPA (Gemini, Claude, ChatGPT, DeepSeek)
    const container = el.closest("fieldset") || el.closest("form") || el.parentElement?.parentElement || document;
    const sendButton = container.querySelector('button[aria-label*="Send"], button[aria-label*="Enviar"], button[data-testid="send-button"]');
    
    if (sendButton && !sendButton.disabled) {
      sendButton.click();
    }
  }
})();