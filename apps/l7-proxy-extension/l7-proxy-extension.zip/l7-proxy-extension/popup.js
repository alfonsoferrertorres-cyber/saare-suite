document.addEventListener("DOMContentLoaded", () => {
  const apiUrlInput = document.getElementById("apiUrl");
  const tenantInput = document.getElementById("tenant");
  const userInput = document.getElementById("user");
  const saveBtn = document.getElementById("saveBtn");
  const statusDiv = document.getElementById("status");

  chrome.storage.local.get("saare_config", (result) => {
    if (result.saare_config) {
      apiUrlInput.value = result.saare_config.apiUrl || "https://api.saare.es";
      tenantInput.value = result.saare_config.tenant || "";
      userInput.value = result.saare_config.user || "";
    }
  });

  saveBtn.addEventListener("click", () => {
    const config = {
      apiUrl: apiUrlInput.value.trim() || "https://api.saare.es",
      tenant: tenantInput.value.trim() || "ORGANISMO_DEMO_01",
      user: userInput.value.trim() || "operador@empresa.com",
      provider: "AGNOSTIC_WEB_PROXY"
    };

    chrome.storage.local.set({ saare_config: config }, () => {
      statusDiv.innerText = "✓ Configuración Sincronizada";
      setTimeout(() => { statusDiv.innerText = ""; }, 2500);
    });
  });
});