// S.A.A.R.E. Service Worker — Pasarela de Inspección Dinámica L7

const DEFAULT_CONFIG = {
  apiUrl: "https://api.saare.es",
  tenant: "ORGANISMO_DEMO_01",
  user: "operador@empresa.com",
  provider: "AGNOSTIC_WEB_PROXY"
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["saare_config"], (result) => {
    if (!result.saare_config) {
      chrome.storage.local.set({ saare_config: DEFAULT_CONFIG });
    }
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "INSPECT_PROMPT_EX_ANTE") {
    handleExAnteInspection(request.payload)
      .then((verdict) => sendResponse({ success: true, verdict }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // Mantiene el canal asíncrono abierto
  }
});

async function handleExAnteInspection(promptText) {
  const store = await chrome.storage.local.get("saare_config");
  const config = store.saare_config || DEFAULT_CONFIG;

  const baseUrl = (config.apiUrl || "https://api.saare.es").replace(/\/+$/, "");
  const endpoint = `${baseUrl}/v1/chat/completions`;

  const payload = {
    prompt: promptText,
    tenant: config.tenant,
    user: config.user,
    provider: config.provider || "AGNOSTIC_WEB_PROXY"
  };

  const headers = {
    "Content-Type": "application/json",
    "x-saare-tenant": config.tenant,
    "x-saare-user": config.user
  };

  const res = await fetch(endpoint, {
    method: "POST",
    headers: headers,
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Error L7 (${res.status}): ${errText}`);
  }

  const data = await res.json();
  return data;
}