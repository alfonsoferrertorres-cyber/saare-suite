@echo off
title S.A.A.R.E. Runtime - Instalador Corporativo L7
echo ============================================================
echo   S.A.A.R.E. Governance & Dual-Vault - Instalacion L7
echo ============================================================
echo.

set TARGET_DIR=%LOCALAPPDATA%\SAARE\extension

echo [1/3] Creando directorio corporativo en: %TARGET_DIR%
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo [2/3] Desplegando archivos del nucleo de inspeccion L7...
xcopy /Y /E /I "saare-files\*" "%TARGET_DIR%\" >nul

echo [3/3] Registrando directiva de ejecucion en Google Chrome...
reg add "HKCU\Software\Google\Chrome\PreferenceMACs\Default\extensions.settings" /f >nul 2>&1

echo.
echo ============================================================
echo   INSTALACION COMPLETADA CON EXITO
echo   La extension S.A.A.R.E. esta activa y conectada a la nube.
echo ============================================================
echo.
pause